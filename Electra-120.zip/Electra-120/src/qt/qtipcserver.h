#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define Electra-Qt message queue name
#define ELECTRAURI_QUEUE_NAME "ElectraURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
